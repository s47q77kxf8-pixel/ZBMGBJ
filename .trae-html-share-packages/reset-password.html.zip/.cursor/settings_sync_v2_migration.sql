-- Settings Sync V2 migration (granular + soft-delete)
-- Run in Supabase SQL editor.

-- 1) Singleton settings table (one row per domain per artist)
create table if not exists public.artist_settings_singleton (
  artist_id uuid not null,
  domain text not null,
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  primary key (artist_id, domain)
);

-- 2) Item settings table (multiple rows, supports soft delete)
create table if not exists public.artist_settings_items (
  artist_id uuid not null,
  domain text not null,
  item_id text not null,
  payload jsonb,
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  created_at timestamptz not null default now(),
  primary key (artist_id, domain, item_id)
);

create index if not exists idx_artist_settings_items_artist_domain
  on public.artist_settings_items (artist_id, domain);

create index if not exists idx_artist_settings_items_artist_updated
  on public.artist_settings_items (artist_id, updated_at desc);

-- 3) Enable RLS
alter table public.artist_settings_singleton enable row level security;
alter table public.artist_settings_items enable row level security;

-- 4) Policies (owner can CRUD own settings)
do $$
begin
  if not exists (
    select 1 from pg_policies where schemaname='public' and tablename='artist_settings_singleton' and policyname='singleton_select_own'
  ) then
    create policy singleton_select_own on public.artist_settings_singleton
      for select using (auth.uid() = artist_id);
  end if;

  if not exists (
    select 1 from pg_policies where schemaname='public' and tablename='artist_settings_singleton' and policyname='singleton_insert_own'
  ) then
    create policy singleton_insert_own on public.artist_settings_singleton
      for insert with check (auth.uid() = artist_id);
  end if;

  if not exists (
    select 1 from pg_policies where schemaname='public' and tablename='artist_settings_singleton' and policyname='singleton_update_own'
  ) then
    create policy singleton_update_own on public.artist_settings_singleton
      for update using (auth.uid() = artist_id) with check (auth.uid() = artist_id);
  end if;

  if not exists (
    select 1 from pg_policies where schemaname='public' and tablename='artist_settings_singleton' and policyname='singleton_delete_own'
  ) then
    create policy singleton_delete_own on public.artist_settings_singleton
      for delete using (auth.uid() = artist_id);
  end if;

  if not exists (
    select 1 from pg_policies where schemaname='public' and tablename='artist_settings_items' and policyname='items_select_own'
  ) then
    create policy items_select_own on public.artist_settings_items
      for select using (auth.uid() = artist_id);
  end if;

  if not exists (
    select 1 from pg_policies where schemaname='public' and tablename='artist_settings_items' and policyname='items_insert_own'
  ) then
    create policy items_insert_own on public.artist_settings_items
      for insert with check (auth.uid() = artist_id);
  end if;

  if not exists (
    select 1 from pg_policies where schemaname='public' and tablename='artist_settings_items' and policyname='items_update_own'
  ) then
    create policy items_update_own on public.artist_settings_items
      for update using (auth.uid() = artist_id) with check (auth.uid() = artist_id);
  end if;

  if not exists (
    select 1 from pg_policies where schemaname='public' and tablename='artist_settings_items' and policyname='items_delete_own'
  ) then
    create policy items_delete_own on public.artist_settings_items
      for delete using (auth.uid() = artist_id);
  end if;
end $$;

-- 5) Optional one-time backfill from old artist_settings.payload
-- Keeps old table untouched; new code can read V2 first and fallback to old.
insert into public.artist_settings_singleton (artist_id, domain, payload, updated_at)
select
  s.artist_id,
  'calculator_settings',
  coalesce(s.payload->'calculatorSettings', '{}'::jsonb),
  coalesce(s.updated_at, now())
from public.artist_settings s
where s.payload is not null
on conflict (artist_id, domain) do update
set payload = excluded.payload,
    updated_at = greatest(public.artist_settings_singleton.updated_at, excluded.updated_at);

insert into public.artist_settings_items (artist_id, domain, item_id, payload, updated_at, deleted_at)
select
  s.artist_id,
  'process_settings',
  coalesce((p.value->>'id'), md5(p.value::text)),
  p.value,
  coalesce(s.updated_at, now()),
  null
from public.artist_settings s,
     lateral jsonb_array_elements(coalesce(s.payload->'processSettings', '[]'::jsonb)) p(value)
on conflict (artist_id, domain, item_id) do update
set payload = excluded.payload,
    deleted_at = null,
    updated_at = greatest(public.artist_settings_items.updated_at, excluded.updated_at);

insert into public.artist_settings_items (artist_id, domain, item_id, payload, updated_at, deleted_at)
select
  s.artist_id,
  'product_settings',
  coalesce((p.value->>'id'), md5(p.value::text)),
  p.value,
  coalesce(s.updated_at, now()),
  null
from public.artist_settings s,
     lateral jsonb_array_elements(coalesce(s.payload->'productSettings', '[]'::jsonb)) p(value)
on conflict (artist_id, domain, item_id) do update
set payload = excluded.payload,
    deleted_at = null,
    updated_at = greatest(public.artist_settings_items.updated_at, excluded.updated_at);

insert into public.artist_settings_items (artist_id, domain, item_id, payload, updated_at, deleted_at)
select
  s.artist_id,
  'templates',
  coalesce((p.value->>'id'), md5(p.value::text)),
  p.value,
  coalesce(s.updated_at, now()),
  null
from public.artist_settings s,
     lateral jsonb_array_elements(coalesce(s.payload->'templates', '[]'::jsonb)) p(value)
on conflict (artist_id, domain, item_id) do update
set payload = excluded.payload,
    deleted_at = null,
    updated_at = greatest(public.artist_settings_items.updated_at, excluded.updated_at);

insert into public.artist_settings_singleton (artist_id, domain, payload, updated_at)
select
  s.artist_id,
  'artist_info',
  coalesce(s.payload->'calculatorSettings'->'artistInfo', '{}'::jsonb),
  coalesce(s.updated_at, now())
from public.artist_settings s
where s.payload is not null
on conflict (artist_id, domain) do update
set payload = excluded.payload,
    updated_at = greatest(public.artist_settings_singleton.updated_at, excluded.updated_at);

insert into public.artist_settings_items (artist_id, domain, item_id, payload, updated_at, deleted_at)
select
  s.artist_id,
  'other_fee_types',
  e.key,
  e.value,
  coalesce(s.updated_at, now()),
  null
from public.artist_settings s,
     lateral jsonb_each(coalesce(s.payload->'calculatorSettings'->'otherFees', '{}'::jsonb)) e
on conflict (artist_id, domain, item_id) do update
set payload = excluded.payload,
    deleted_at = null,
    updated_at = greatest(public.artist_settings_items.updated_at, excluded.updated_at);

insert into public.artist_settings_items (artist_id, domain, item_id, payload, updated_at, deleted_at)
select
  s.artist_id,
  'extra_pricing_up',
  coalesce((p.value->>'id'), md5(p.value::text)),
  p.value,
  coalesce(s.updated_at, now()),
  null
from public.artist_settings s,
     lateral jsonb_array_elements(coalesce(s.payload->'calculatorSettings'->'extraPricingUp', '[]'::jsonb)) p(value)
on conflict (artist_id, domain, item_id) do update
set payload = excluded.payload,
    deleted_at = null,
    updated_at = greatest(public.artist_settings_items.updated_at, excluded.updated_at);

insert into public.artist_settings_items (artist_id, domain, item_id, payload, updated_at, deleted_at)
select
  s.artist_id,
  'extra_pricing_down',
  coalesce((p.value->>'id'), md5(p.value::text)),
  p.value,
  coalesce(s.updated_at, now()),
  null
from public.artist_settings s,
     lateral jsonb_array_elements(coalesce(s.payload->'calculatorSettings'->'extraPricingDown', '[]'::jsonb)) p(value)
on conflict (artist_id, domain, item_id) do update
set payload = excluded.payload,
    deleted_at = null,
    updated_at = greatest(public.artist_settings_items.updated_at, excluded.updated_at);

insert into public.artist_settings_items (artist_id, domain, item_id, payload, updated_at, deleted_at)
select
  s.artist_id,
  'usage_coefficients',
  e.key,
  e.value,
  coalesce(s.updated_at, now()),
  null
from public.artist_settings s,
     lateral jsonb_each(coalesce(s.payload->'calculatorSettings'->'usageCoefficients', '{}'::jsonb)) e
on conflict (artist_id, domain, item_id) do update
set payload = excluded.payload,
    deleted_at = null,
    updated_at = greatest(public.artist_settings_items.updated_at, excluded.updated_at);

insert into public.artist_settings_items (artist_id, domain, item_id, payload, updated_at, deleted_at)
select
  s.artist_id,
  'urgent_coefficients',
  e.key,
  e.value,
  coalesce(s.updated_at, now()),
  null
from public.artist_settings s,
     lateral jsonb_each(coalesce(s.payload->'calculatorSettings'->'urgentCoefficients', '{}'::jsonb)) e
on conflict (artist_id, domain, item_id) do update
set payload = excluded.payload,
    deleted_at = null,
    updated_at = greatest(public.artist_settings_items.updated_at, excluded.updated_at);

insert into public.artist_settings_items (artist_id, domain, item_id, payload, updated_at, deleted_at)
select
  s.artist_id,
  'same_model_coefficients',
  e.key,
  e.value,
  coalesce(s.updated_at, now()),
  null
from public.artist_settings s,
     lateral jsonb_each(coalesce(s.payload->'calculatorSettings'->'sameModelCoefficients', '{}'::jsonb)) e
on conflict (artist_id, domain, item_id) do update
set payload = excluded.payload,
    deleted_at = null,
    updated_at = greatest(public.artist_settings_items.updated_at, excluded.updated_at);

insert into public.artist_settings_items (artist_id, domain, item_id, payload, updated_at, deleted_at)
select
  s.artist_id,
  'discount_coefficients',
  e.key,
  e.value,
  coalesce(s.updated_at, now()),
  null
from public.artist_settings s,
     lateral jsonb_each(coalesce(s.payload->'calculatorSettings'->'discountCoefficients', '{}'::jsonb)) e
on conflict (artist_id, domain, item_id) do update
set payload = excluded.payload,
    deleted_at = null,
    updated_at = greatest(public.artist_settings_items.updated_at, excluded.updated_at);

insert into public.artist_settings_items (artist_id, domain, item_id, payload, updated_at, deleted_at)
select
  s.artist_id,
  'platform_fees',
  e.key,
  e.value,
  coalesce(s.updated_at, now()),
  null
from public.artist_settings s,
     lateral jsonb_each(coalesce(s.payload->'calculatorSettings'->'platformFees', '{}'::jsonb)) e
on conflict (artist_id, domain, item_id) do update
set payload = excluded.payload,
    deleted_at = null,
    updated_at = greatest(public.artist_settings_items.updated_at, excluded.updated_at);
