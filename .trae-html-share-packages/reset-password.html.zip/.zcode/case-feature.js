

// ==================================================================
// ===== 案例生成与案例库 =====
// ==================================================================
// 概述：
// - 从订单一键生成案例展示图，保存到本机案例库并关联订单（不参与云端同步）。
// - 案例元数据存 localStorage 'caseLibrary'；图片本体（制品图/水印图/成品图/缩略图）
//   存 IndexedDB 'mettonCaseDB'，IndexedDB 不可用时降级存 localStorage。
// - 画布比例（1:1 / 3:4 / 自定义）指案例图整体宽高；制品 PNG 始终按原图比例
//   等比缩放、居中，不拉伸、不裁切、保留透明。
// - 预览与导出共用 buildCaseCanvasHtml()，保证所见即所得；切换配置纯 DOM 更新，
//   实时生效，html2canvas 只在导出/保存时调用。

let caseLibrary = [];
let _caseState = null;
const _caseImgCache = {};    // imgId -> { dataUrl, w, h }
const _caseShadowCache = {}; // imgId -> { url, bear }（轮廓投影预烘焙结果）
let _caseDbPromise = null;
let _caseViewId = null;

const CASE_USER_TYPES = ['美工', '作者', '画师', '题字'];
const CASE_BG_PRESETS = ['#ffffff', '#f7f5f0', '#f2efe9', '#fdf0f0', '#eef4fb', '#eefaf1', '#fff8e6', '#e8e4f6', '#2b2b2b', '#1d2430'];

// ---------- IndexedDB 图片仓 ----------
function caseDbOpen() {
    if (!window.indexedDB) return Promise.resolve(null);
    if (_caseDbPromise) return _caseDbPromise;
    _caseDbPromise = new Promise(function (resolve) {
        let settled = false;
        const done = function (v) { if (!settled) { settled = true; resolve(v); } };
        try {
            const req = indexedDB.open('mettonCaseDB', 1);
            req.onupgradeneeded = function (e) {
                const db = e.target.result;
                if (!db.objectStoreNames.contains('images')) db.createObjectStore('images');
            };
            req.onsuccess = function (e) { done(e.target.result); };
            req.onerror = function () { done(null); };
            req.onblocked = function () { done(null); };
            setTimeout(function () { done(null); }, 3000);
        } catch (_) { done(null); }
    });
    return _caseDbPromise;
}
async function caseImgPut(id, dataUrl) {
    if (!id) return;
    const db = await caseDbOpen();
    if (db) {
        await new Promise(function (resolve) {
            try {
                const tx = db.transaction('images', 'readwrite');
                tx.objectStore('images').put(dataUrl, id);
                tx.oncomplete = resolve;
                tx.onerror = resolve;
                tx.onabort = resolve;
            } catch (_) { resolve(); }
        });
        return;
    }
    try { localStorage.setItem('caseImg_' + id, dataUrl); }
    catch (e) { console.error('案例图片保存失败(降级):', e); showGlobalToast('本地空间不足，图片可能未完整保存'); }
}
async function caseImgGet(id) {
    if (!id) return null;
    const db = await caseDbOpen();
    if (db) {
        const v = await new Promise(function (resolve) {
            try {
                const tx = db.transaction('images', 'readonly');
                const rq = tx.objectStore('images').get(id);
                rq.onsuccess = function () { resolve(rq.result || null); };
                rq.onerror = function () { resolve(null); };
            } catch (_) { resolve(null); }
        });
        if (v) return v;
    }
    try { return localStorage.getItem('caseImg_' + id); } catch (_) { return null; }
}
async function caseImgDelete(id) {
    if (!id) return;
    const db = await caseDbOpen();
    if (db) {
        await new Promise(function (resolve) {
            try {
                const tx = db.transaction('images', 'readwrite');
                tx.objectStore('images').delete(id);
                tx.oncomplete = resolve;
                tx.onerror = resolve;
            } catch (_) { resolve(); }
        });
    }
    try { localStorage.removeItem('caseImg_' + id); } catch (_) {}
}

// ---------- 图片加载 / 压缩 / 投影烘焙 ----------
function caseLoadImageEl(dataUrl) {
    return new Promise(function (resolve, reject) {
        const img = new Image();
        img.onload = function () { resolve(img); };
        img.onerror = function () { reject(new Error('图片加载失败')); };
        img.src = dataUrl;
    });
}
function caseReadFileAsDataUrl(file) {
    return new Promise(function (resolve, reject) {
        const reader = new FileReader();
        reader.onload = function () { resolve(String(reader.result || '')); };
        reader.onerror = function () { reject(new Error('读取文件失败')); };
        reader.readAsDataURL(file);
    });
}
// 等比缩到最大边 maxEdge；mime 指定输出格式（浏览器不支持 webp 时上层需检测前缀回退）
async function caseCompressDataUrl(dataUrl, maxEdge, mime, quality) {
    const img = await caseLoadImageEl(dataUrl);
    const ow = img.naturalWidth || 1, oh = img.naturalHeight || 1;
    const s = Math.min(1, maxEdge / Math.max(ow, oh));
    const w = Math.max(1, Math.round(ow * s)), h = Math.max(1, Math.round(oh * s));
    const cv = document.createElement('canvas');
    cv.width = w; cv.height = h;
    cv.getContext('2d').drawImage(img, 0, 0, w, h);
    return cv.toDataURL(mime, quality);
}
async function caseCompressCanvas(canvas, maxEdge, mime, quality) {
    const s = Math.min(1, maxEdge / Math.max(canvas.width, canvas.height));
    if (s >= 1 && mime !== 'image/jpeg') return canvas.toDataURL(mime, quality);
    const cv = document.createElement('canvas');
    cv.width = Math.max(1, Math.round(canvas.width * s));
    cv.height = Math.max(1, Math.round(canvas.height * s));
    const ctx = cv.getContext('2d');
    if (mime === 'image/jpeg') { ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, cv.width, cv.height); }
    ctx.drawImage(canvas, 0, 0, cv.width, cv.height);
    return cv.toDataURL(mime, quality);
}
// 制品图上传压缩：最大边 1600 保透明（优先 webp，回退 png）；jpeg 用 jpeg
async function caseCompressUploadData(dataUrl, srcType) {
    const keepAlpha = /png|webp/i.test(srcType || '');
    let out;
    if (keepAlpha) {
        out = await caseCompressDataUrl(dataUrl, 1600, 'image/webp', 0.9);
        if (!out || out.indexOf('data:image/webp') !== 0) out = await caseCompressDataUrl(dataUrl, 1600, 'image/png');
    } else {
        out = await caseCompressDataUrl(dataUrl, 1600, 'image/jpeg', 0.88);
    }
    if (out && out.length > 1600 * 1024) {
        out = await caseCompressDataUrl(dataUrl, 1000, keepAlpha ? 'image/webp' : 'image/jpeg', 0.82);
        if (keepAlpha && out && out.indexOf('data:image/webp') !== 0) out = await caseCompressDataUrl(dataUrl, 1000, 'image/png');
    }
    return out;
}
// 轮廓投影预烘焙：画原图投影后用 destination-out 抠掉本体，得到随透明轮廓的落影
// html2canvas 不支持 CSS filter，预烘焙才能保证预览与导出一致
async function caseBakeShadow(imgId) {
    if (_caseShadowCache[imgId]) return _caseShadowCache[imgId];
    const c = _caseImgCache[imgId];
    if (!c) return null;
    try {
        const img = await caseLoadImageEl(c.dataUrl);
        const w = img.naturalWidth, h = img.naturalHeight;
        if (!w || !h) return null;
        const bear = Math.round(Math.max(w, h) * 0.1) + 6;
        const cv = document.createElement('canvas');
        cv.width = w + bear * 2; cv.height = h + bear * 2;
        const ctx = cv.getContext('2d');
        ctx.shadowColor = 'rgba(0,0,0,0.38)';
        ctx.shadowBlur = Math.round(bear * 0.7);
        ctx.shadowOffsetY = Math.round(bear * 0.22);
        ctx.drawImage(img, bear, bear, w, h);
        ctx.globalCompositeOperation = 'destination-out';
        ctx.drawImage(img, bear, bear, w, h);
        const url = cv.toDataURL('image/png');
        const rec = { url: url, bear: bear };
        _caseShadowCache[imgId] = rec;
        return rec;
    } catch (e) { console.error('投影烘焙失败:', e); return null; }
}
async function caseEnsureImagesLoaded(imgIds) {
    let changed = false;
    for (const id of (imgIds || [])) {
        if (!id || _caseImgCache[id]) continue;
        const dataUrl = await caseImgGet(id);
        if (!dataUrl) continue;
        try {
            const img = await caseLoadImageEl(dataUrl);
            _caseImgCache[id] = { dataUrl: dataUrl, w: img.naturalWidth || 1, h: img.naturalHeight || 1 };
            changed = true;
        } catch (_) {}
    }
    return changed;
}
async function caseEnsureShadows(imgIds) {
    let changed = false;
    for (const id of (imgIds || [])) {
        if (!id || _caseShadowCache[id]) continue;
        if (!_caseImgCache[id]) continue;
        const r = await caseBakeShadow(id);
        if (r) changed = true;
    }
    return changed;
}

// ---------- 数据层 ----------
function loadCaseLibrary() {
    try {
        const raw = localStorage.getItem('caseLibrary');
        caseLibrary = raw ? (JSON.parse(raw) || []) : [];
        if (!Array.isArray(caseLibrary)) caseLibrary = [];
    } catch (e) {
        console.error('加载案例库失败:', e);
        caseLibrary = [];
    }
    return caseLibrary;
}
function saveCaseLibrary() {
    try { localStorage.setItem('caseLibrary', JSON.stringify(caseLibrary)); }
    catch (e) {
        console.error('保存案例库失败:', e);
        showGlobalToast('案例库保存失败（本地存储空间不足）');
    }
}
function caseNewState() {
    const artist = (defaultSettings && defaultSettings.artistInfo) || {};
    const role = CASE_USER_TYPES.indexOf(artist.role) >= 0 ? artist.role : '美工';
    const name = artist.id || '';
    return {
        id: null,
        orderId: '', orderTitle: '',
        config: {
            ratio: '1:1', width: 1080, height: 1080,
            bg: { type: 'color', color: '#f7f5f0' },
            toggles: { title: true, userInfo: true, productInfo: true },
            userInfoTypes: [role],
            mockupId: 'card',
            watermark: { enabled: false, type: 'text', text: name ? '@' + name : '', imgId: '', position: 'br', opacity: 0.3, scale: 1 }
        },
        fields: { title: '', ip: '', character: '', products: '', userInfo: { '美工': name, '作者': name, '画师': name, '题字': name } },
        images: [],
        exportImgId: '', exportThumbId: '', exportFormat: 'png',
        createdAt: null, updatedAt: null
    };
}
function caseNormalizeState(st) {
    const def = caseNewState();
    st.config = Object.assign({}, def.config, st.config || {});
    st.config.bg = Object.assign({}, def.config.bg, st.config.bg || {});
    st.config.toggles = Object.assign({}, def.config.toggles, st.config.toggles || {});
    st.config.watermark = Object.assign({}, def.config.watermark, st.config.watermark || {});
    st.fields = Object.assign({}, def.fields, st.fields || {});
    st.fields.userInfo = Object.assign({}, def.fields.userInfo, (st.fields && st.fields.userInfo) || {});
    st.images = Array.isArray(st.images) ? st.images : [];
    st.config.width = Math.min(4000, Math.max(200, parseInt(st.config.width, 10) || 1080));
    st.config.height = Math.min(4000, Math.max(200, parseInt(st.config.height, 10) || 1080));
    if (!Array.isArray(st.config.userInfoTypes) || !st.config.userInfoTypes.length) st.config.userInfoTypes = def.config.userInfoTypes;
    st.orderId = st.orderId || '';
    st.orderTitle = st.orderTitle || '';
    st.exportImgId = st.exportImgId || '';
    st.exportThumbId = st.exportThumbId || '';
    st.exportFormat = st.exportFormat || 'png';
    return st;
}
function caseRecordFromState(st) {
    return {
        id: st.id, orderId: st.orderId || '', orderTitle: st.orderTitle || '',
        config: JSON.parse(JSON.stringify(st.config)),
        fields: JSON.parse(JSON.stringify(st.fields)),
        images: (st.images || []).slice(),
        exportImgId: st.exportImgId || '', exportThumbId: st.exportThumbId || '', exportFormat: st.exportFormat || 'png',
        createdAt: st.createdAt || null, updatedAt: st.updatedAt || null
    };
}

// ---------- 订单带入 ----------
function caseOrderOptionsHtml() {
    const st = _caseState;
    let html = '<option value="">不关联订单</option>';
    (history || []).forEach(function (o) {
        if (!o) return;
        const t = String(o.projectName || '').trim() || '（无标题订单）';
        const d = o.timestamp ? String(o.timestamp).slice(0, 10) : '';
        const sel = st && st.orderId != null && String(st.orderId) === String(o.id) ? ' selected' : '';
        html += '<option value="' + escapeHtml(String(o.id)) + '"' + sel + '>' + escapeHtml(t + (d ? '（' + d + '）' : '')) + '</option>';
    });
    return html;
}
function caseProductsTextFromOrder(order) {
    const names = [];
    const push = function (pp, gift) {
        if (!pp) return;
        const ps = (productSettings || []).find(function (p) { return p && String(p.id) === String(pp.type); });
        const name = String(pp.moduleName || '').trim() || (ps && ps.name) || '';
        if (!name) return;
        const label = name + (gift ? '（赠）' : '');
        if (names.indexOf(label) < 0) names.push(label);
    };
    (order.productPrices || []).forEach(function (pp) { push(pp, false); });
    (order.giftPrices || []).forEach(function (pp) { push(pp, true); });
    return names.join('、');
}
async function applyCaseOrder(orderId) {
    const st = _caseState;
    if (!st) return;
    if (!orderId) { st.orderId = ''; st.orderTitle = ''; renderCaseForm(); return; }
    const order = (history || []).find(function (o) { return o && String(o.id) === String(orderId); });
    if (!order) { showGlobalToast('未找到该订单'); return; }
    st.orderId = order.id;
    st.orderTitle = String(order.projectName || '').trim();
    // 自动带入字段（用户信息身份与名字保持当前设置，可手动再改）
    st.fields.title = String(order.projectName || '').trim();
    st.fields.ip = String(order.projectOrigin || '').trim();
    st.fields.character = String(order.characterName || '').trim();
    st.fields.products = caseProductsTextFromOrder(order);
    // 读取该订单此前上传过的制品图（取最近一条案例）
    let adopted = false;
    if (st.images.length === 0) {
        const prev = caseLibrary
            .filter(function (c) { return c && c.orderId != null && String(c.orderId) === String(orderId) && c.images && c.images.length; })
            .sort(function (a, b) { return String(b.updatedAt || '').localeCompare(String(a.updatedAt || '')); })[0];
        if (prev) { st.images = prev.images.slice(); adopted = true; }
    }
    renderCaseForm();
    renderCasePreview();
    await caseEnsureImagesLoaded(st.images.slice());
    if (_caseState && caseActiveMockup().shadow) await caseEnsureShadows(_caseState.images.slice());
    if (_caseState) renderCasePreview();
    showGlobalToast(adopted ? '已带入订单字段与此前上传的制品图' : '已带入订单字段');
}

// ---------- 样机模板 ----------
// 通用网格排布：1 图居中 / 2 图上下或左右 / 3 图一大两小 / ≥4 图均分网格
function caseGridSlots(n, area) {
    const slots = [];
    if (n <= 0) return slots;
    const gap = Math.round(Math.min(area.w, area.h) * 0.04);
    if (n === 1) { slots.push({ x: area.x, y: area.y, w: area.w, h: area.h }); return slots; }
    const portrait = area.h >= area.w;
    if (n === 2) {
        if (portrait) {
            const h2 = Math.floor((area.h - gap) / 2);
            slots.push({ x: area.x, y: area.y, w: area.w, h: h2 });
            slots.push({ x: area.x, y: area.y + h2 + gap, w: area.w, h: h2 });
        } else {
            const w2 = Math.floor((area.w - gap) / 2);
            slots.push({ x: area.x, y: area.y, w: w2, h: area.h });
            slots.push({ x: area.x + w2 + gap, y: area.y, w: w2, h: area.h });
        }
        return slots;
    }
    if (n === 3) {
        if (portrait) {
            const hBig = Math.floor((area.h - gap) * 0.58);
            const hSmall = area.h - gap - hBig;
            const wSmall = Math.floor((area.w - gap) / 2);
            slots.push({ x: area.x, y: area.y, w: area.w, h: hBig });
            slots.push({ x: area.x, y: area.y + hBig + gap, w: wSmall, h: hSmall });
            slots.push({ x: area.x + wSmall + gap, y: area.y + hBig + gap, w: area.w - wSmall - gap, h: hSmall });
        } else {
            const wBig = Math.floor((area.w - gap) * 0.58);
            const hSmall = Math.floor((area.h - gap) / 2);
            slots.push({ x: area.x, y: area.y, w: wBig, h: area.h });
            slots.push({ x: area.x + wBig + gap, y: area.y, w: area.w - wBig - gap, h: hSmall });
            slots.push({ x: area.x + wBig + gap, y: area.y + hSmall + gap, w: area.w - wBig - gap, h: area.h - hSmall - gap });
        }
        return slots;
    }
    const cols = portrait ? 2 : (n <= 4 ? 2 : 3);
    const rows = Math.ceil(n / cols);
    const cw = Math.floor((area.w - gap * (cols - 1)) / cols);
    const ch = Math.floor((area.h - gap * (rows - 1)) / rows);
    for (let i = 0; i < n; i++) {
        const r = Math.floor(i / cols), c = i % cols;
        slots.push({ x: area.x + c * (cw + gap), y: area.y + r * (ch + gap), w: cw, h: ch });
    }
    return slots;
}
// 单图海报：首图大图居中，其余排底部一行
function casePosterSlots(n, area) {
    if (n <= 1) return n === 1 ? [{ x: area.x, y: area.y, w: area.w, h: area.h }] : [];
    const gap = Math.round(Math.min(area.w, area.h) * 0.04);
    const hBig = Math.floor((area.h - gap) * 0.68);
    const slots = [{ x: area.x, y: area.y, w: area.w, h: hBig }];
    const rest = n - 1;
    const cw = Math.floor((area.w - gap * (rest - 1)) / rest);
    for (let i = 0; i < rest; i++) {
        slots.push({ x: area.x + i * (cw + gap), y: area.y + hBig + gap, w: cw, h: area.h - hBig - gap });
    }
    return slots;
}
const CASE_MOCKUPS = [
    {
        id: 'plain', name: '无装饰', mat: 'none', shadow: false,
        desc: '制品图直接排列',
        diagram: '<div class="case-md-rect" style="left:16%;top:26%;width:38%;height:30%;"></div><div class="case-md-rect" style="left:58%;top:42%;width:28%;height:30%;"></div>',
        slots: caseGridSlots
    },
    {
        id: 'card', name: '简约卡片', mat: 'card', shadow: false,
        desc: '白底圆角卡片垫底，柔和投影',
        diagram: '<div class="case-md-rect" style="left:12%;top:18%;width:44%;height:40%;border-radius:12%;"></div><div class="case-md-rect" style="left:50%;top:36%;width:38%;height:44%;border-radius:12%;"></div>',
        slots: caseGridSlots
    },
    {
        id: 'poster', name: '单图海报', mat: 'card', shadow: false,
        desc: '首图大图居中，其余排底部',
        diagram: '<div class="case-md-rect" style="left:24%;top:10%;width:52%;height:58%;border-radius:10%;"></div><div class="case-md-rect" style="left:24%;top:76%;width:20%;height:15%;border-radius:8%;"></div><div class="case-md-rect" style="left:50%;top:76%;width:20%;height:15%;border-radius:8%;"></div>',
        slots: casePosterSlots
    },
    {
        id: 'collage', name: '错落拼贴', mat: 'polaroid', shadow: false,
        desc: '白边照片卡轻微旋转、错落分布',
        diagram: '<div class="case-md-rect" style="left:14%;top:20%;width:38%;height:42%;border-radius:6%;transform:rotate(-6deg);"></div><div class="case-md-rect" style="left:48%;top:36%;width:38%;height:42%;border-radius:6%;transform:rotate(5deg);"></div>',
        slots: caseGridSlots
    },
    {
        id: 'shadow', name: '实物投影', mat: 'none', shadow: true,
        desc: '按制品透明轮廓生成落影，模拟实物',
        diagram: '<div class="case-md-round" style="left:22%;top:22%;width:44%;height:44%;"></div><div class="case-md-round" style="left:52%;top:42%;width:30%;height:30%;opacity:.85;"></div>',
        slots: caseGridSlots
    }
];
function caseActiveMockup() {
    const id = _caseState && _caseState.config && _caseState.config.mockupId;
    return CASE_MOCKUPS.find(function (m) { return m.id === id; }) || CASE_MOCKUPS[0];
}

// ---------- 画布渲染 ----------
function caseCanvasTextColor(bg) {
    if (!bg || bg.type !== 'color' || !bg.color) return '#3a3a3a';
    const hex = String(bg.color).replace('#', '');
    if (hex.length < 6) return '#3a3a3a';
    const r = parseInt(hex.slice(0, 2), 16), g = parseInt(hex.slice(2, 4), 16), b = parseInt(hex.slice(4, 6), 16);
    const lum = 0.299 * r + 0.587 * g + 0.114 * b;
    return lum >= 150 ? '#333333' : '#f2f2f2';
}
function caseInfoLines(st) {
    const lines = [];
    const types = st.config.userInfoTypes || [];
    CASE_USER_TYPES.forEach(function (type) {
        if (types.indexOf(type) < 0) return;
        const name = String((st.fields.userInfo && st.fields.userInfo[type]) || '').trim();
        if (!name) return;
        lines.push(type + '：' + name);
    });
    return lines;
}
function caseProductParts(st) {
    const parts = [];
    const f = st.fields || {};
    const ip = String(f.ip || '').trim();
    const ch = String(f.character || '').trim();
    const pd = String(f.products || '').trim();
    if (ip) parts.push('IP：' + ip);
    if (ch) parts.push('角色：' + ch);
    if (pd) parts.push('制品：' + pd);
    return parts;
}
function caseWatermarkHtml(st, W, H, color) {
    const wm = st.config.watermark;
    if (!wm || !wm.enabled) return '';
    const scale = Math.min(3, Math.max(0.5, Number(wm.scale) || 1));
    let unitInner = '', unitW = 0, unitH = 0;
    if (wm.type === 'image') {
        const c = _caseImgCache[wm.imgId];
        if (!c) return '';
        const h = Math.round(W * 0.075 * scale);
        const w = Math.max(1, Math.round(h * (c.w / c.h)));
        unitInner = '<img src="' + c.dataUrl + '" style="width:' + w + 'px;height:' + h + 'px;">';
        unitW = w; unitH = h;
    } else {
        const text = String(wm.text || '').trim();
        if (!text) return '';
        const fs = Math.round(W * 0.022 * scale);
        unitInner = '<span class="case-wm-unit" style="font-size:' + fs + 'px;color:' + color + ';">' + escapeHtml(text) + '</span>';
        unitW = Math.round(text.length * fs * 0.62 + fs * 0.4);
        unitH = Math.round(fs * 1.5);
    }
    const opacity = Math.min(1, Math.max(0.05, Number(wm.opacity) || 0.3));
    if (wm.position === 'tile') {
        const gapX = Math.round(unitW * 1.1), gapY = Math.round(unitH * 1.3);
        const diag = Math.ceil(Math.sqrt(W * W + H * H));
        const coverW = diag + unitW * 2, coverH = diag + unitH * 2;
        const cols = Math.ceil(coverW / (unitW + gapX)) + 1;
        const rows = Math.ceil(coverH / (unitH + gapY)) + 1;
        if (cols * rows > 900) return ''; // 极端尺寸保护
        let cells = '';
        for (let r = 0; r < rows; r++) {
            for (let cIdx = 0; cIdx < cols; cIdx++) {
                cells += '<span style="display:inline-block;margin:' + Math.round(gapY / 2) + 'px ' + Math.round(gapX / 2) + 'px;">' + unitInner + '</span>';
            }
        }
        return '<div class="case-watermark" style="opacity:' + opacity + ';">'
            + '<div class="case-wm-tile" style="left:' + Math.round((W - coverW) / 2) + 'px;top:' + Math.round((H - coverH) / 2) + 'px;width:' + coverW + 'px;height:' + coverH + 'px;">' + cells + '</div>'
            + '</div>';
    }
    const m = Math.round(W * 0.045);
    let pos = '';
    if (wm.position === 'tl') pos = 'left:' + m + 'px;top:' + m + 'px;';
    else if (wm.position === 'tr') pos = 'right:' + m + 'px;top:' + m + 'px;';
    else if (wm.position === 'bl') pos = 'left:' + m + 'px;bottom:' + m + 'px;';
    else if (wm.position === 'br') pos = 'right:' + m + 'px;bottom:' + m + 'px;';
    else pos = 'left:50%;top:50%;transform:translate(-50%,-50%);';
    return '<div class="case-watermark" style="opacity:' + opacity + ';"><div style="position:absolute;' + pos + ';">' + unitInner + '</div></div>';
}
function buildCaseCanvasHtml(st) {
    const W = st.config.width, H = st.config.height;
    const cfg = st.config;
    const pad = Math.round(W * 0.055);
    const txtColor = caseCanvasTextColor(cfg.bg);
    const titleText = (cfg.toggles.title ? (st.fields.title || '') : '').trim();
    const infoArr = cfg.toggles.userInfo ? caseInfoLines(st) : [];
    const prodParts = cfg.toggles.productInfo ? caseProductParts(st) : [];
    const prodText = prodParts.join('　');
    const titleFs = Math.round(W * 0.044);
    const titleLh = Math.round(titleFs * 1.35);
    const titleZoneH = titleText ? titleLh * 2 : 0;
    const infoFs = Math.round(W * 0.027);
    const infoLh = Math.round(infoFs * 1.7);
    const bottomCount = (prodText ? 1 : 0) + infoArr.length;
    const bottomZoneH = bottomCount ? bottomCount * infoLh + Math.round(W * 0.012) : 0;
    const gapY = Math.round(W * 0.025);
    const topUsed = titleZoneH ? titleZoneH + gapY : 0;
    const bottomUsed = bottomZoneH ? bottomZoneH + gapY : 0;
    const area = {
        x: pad,
        y: pad + topUsed,
        w: W - pad * 2,
        h: Math.max(Math.round(H * 0.18), H - pad * 2 - topUsed - bottomUsed)
    };
    const mockup = caseActiveMockup();
    const slots = mockup.slots(st.images.length, area);
    // 制品层：占位区只是区域边界，PNG 在其中等比缩放居中，不拉伸不裁切
    const rots = [-3.5, 2.5, -2, 4, 3, -4.5];
    let productsHtml = '';
    for (let i = 0; i < st.images.length; i++) {
        const imgId = st.images[i];
        const slot = slots[i] || { x: area.x, y: area.y, w: area.w, h: area.h };
        const c = _caseImgCache[imgId];
        let slotStyle = 'left:' + slot.x + 'px;top:' + slot.y + 'px;width:' + slot.w + 'px;height:' + slot.h + 'px;';
        if (mockup.id === 'collage') slotStyle += 'transform:rotate(' + rots[i % rots.length] + 'deg);';
        let matHtml = '';
        let cx = 0, cy = 0, cw = slot.w, ch = slot.h;
        if (mockup.mat === 'card') {
            const m = Math.round(Math.min(slot.w, slot.h) * 0.09);
            matHtml = '<div class="case-slot-mat"></div>';
            cx = m; cy = m; cw = slot.w - m * 2; ch = slot.h - m * 2;
        } else if (mockup.mat === 'polaroid') {
            const m = Math.round(Math.min(slot.w, slot.h) * 0.07);
            const mb = Math.round(Math.min(slot.w, slot.h) * 0.16);
            matHtml = '<div class="case-slot-mat" style="border-radius:' + Math.max(6, Math.round(m * 0.7)) + 'px;"></div>';
            cx = m; cy = m; cw = slot.w - m * 2; ch = slot.h - m - mb;
        }
        let inner = '';
        if (!c) {
            inner = '<div class="case-slot-loading" style="left:' + cx + 'px;top:' + cy + 'px;width:' + Math.max(0, cw) + 'px;height:' + Math.max(0, ch) + 'px;">…</div>';
        } else {
            const s = Math.min(cw / c.w, ch / c.h);
            const dw = Math.max(1, Math.round(c.w * s)), dh = Math.max(1, Math.round(c.h * s));
            const dx = cx + Math.round((cw - dw) / 2), dy = cy + Math.round((ch - dh) / 2);
            if (mockup.shadow) {
                const sh = _caseShadowCache[imgId];
                if (sh && sh.url) {
                    const bear = Math.round(sh.bear * s);
                    inner += '<img src="' + sh.url + '" style="position:absolute;left:' + (dx - bear) + 'px;top:' + (dy - bear) + 'px;width:' + (dw + bear * 2) + 'px;height:' + (dh + bear * 2) + 'px;">';
                }
            }
            inner += '<img src="' + c.dataUrl + '" style="position:absolute;left:' + dx + 'px;top:' + dy + 'px;width:' + dw + 'px;height:' + dh + 'px;">';
        }
        productsHtml += '<div class="case-slot" style="' + slotStyle + '">' + matHtml + inner + '</div>';
    }
    // 文字层
    let textHtml = '';
    if (titleText) {
        textHtml += '<div class="case-title" data-case-fit="' + titleFs + '" data-case-fit-min="' + Math.round(titleFs * 0.55) + '"'
            + ' style="left:' + pad + 'px;top:' + pad + 'px;width:' + (W - pad * 2) + 'px;height:' + titleZoneH + 'px;font-size:' + titleFs + 'px;color:' + txtColor + ';">'
            + escapeHtml(titleText) + '</div>';
    }
    if (bottomCount) {
        let inner = '';
        if (prodText) {
            inner += '<div class="case-info-line" data-case-fit="' + infoFs + '" data-case-fit-min="' + Math.round(infoFs * 0.6) + '"'
                + ' style="height:' + infoLh + 'px;font-size:' + infoFs + 'px;color:' + txtColor + ';">' + escapeHtml(prodText) + '</div>';
        }
        infoArr.forEach(function (line) {
            inner += '<div class="case-info-line" style="height:' + infoLh + 'px;font-size:' + infoFs + 'px;color:' + txtColor + ';">' + escapeHtml(line) + '</div>';
        });
        textHtml += '<div class="case-info-block" style="left:' + pad + 'px;bottom:' + pad + 'px;width:' + (W - pad * 2) + 'px;height:' + bottomZoneH + 'px;">' + inner + '</div>';
    }
    const bgStyle = cfg.bg.type === 'color' ? (cfg.bg.color || '#ffffff') : 'transparent';
    return '<div class="case-canvas" style="width:' + W + 'px;height:' + H + 'px;background:' + bgStyle + ';">'
        + productsHtml + textHtml + caseWatermarkHtml(st, W, H, txtColor)
        + '</div>';
}
// 文本字号适配：超出容器则逐级缩小字号，仍溢出截字加省略号
function casePrepareCanvasEl(root) {
    if (!root) return;
    const els = root.querySelectorAll('[data-case-fit]');
    Array.prototype.forEach.call(els, function (el) {
        const minFs = parseInt(el.getAttribute('data-case-fit-min'), 10) || 12;
        let fs = parseInt(el.getAttribute('data-case-fit'), 10);
        if (!isFinite(fs)) return;
        el.style.fontSize = fs + 'px';
        let guard = 40;
        while (guard-- > 0 && fs > minFs && (el.scrollHeight > el.clientHeight + 1 || el.scrollWidth > el.clientWidth + 1)) {
            fs -= 2;
            el.style.fontSize = fs + 'px';
        }
        if (el.scrollHeight > el.clientHeight + 1 || el.scrollWidth > el.clientWidth + 1) {
            let txt = el.textContent || '';
            while (txt.length > 1 && (el.scrollHeight > el.clientHeight + 1 || el.scrollWidth > el.clientWidth + 1)) {
                txt = txt.slice(0, -2);
                el.textContent = txt + '…';
            }
        }
    });
}

// ---------- 预览 ----------
function renderCasePreview() {
    const wrap = document.getElementById('casePreviewCanvasWrap');
    if (!wrap || !_caseState) return;
    const st = _caseState;
    wrap.innerHTML = buildCaseCanvasHtml(st);
    wrap.classList.toggle('transparent', st.config.bg.type === 'transparent');
    casePrepareCanvasEl(wrap.firstElementChild);
    fitCasePreview();
    // 图片 / 投影 / 水印图异步就绪后各补绘一次
    caseEnsureImagesLoaded((st.images || []).slice()).then(function (changed) {
        if (changed && _caseState) renderCasePreview();
    });
    if (caseActiveMockup().shadow) {
        caseEnsureShadows((st.images || []).slice()).then(function (changed) {
            if (changed && _caseState) renderCasePreview();
        });
    }
    const wm = st.config.watermark;
    if (wm && wm.enabled && wm.type === 'image' && wm.imgId) {
        caseEnsureImagesLoaded([wm.imgId]).then(function (changed) {
            if (changed && _caseState) renderCasePreview();
        });
    }
}
function fitCasePreview() {
    const stage = document.getElementById('casePreviewStage');
    const wrap = document.getElementById('casePreviewCanvasWrap');
    if (!stage || !wrap || !_caseState) return;
    const rect = stage.getBoundingClientRect();
    const availW = Math.max(60, rect.width - 28);
    const availH = Math.max(60, rect.height - 28);
    const s = Math.min(availW / _caseState.config.width, availH / _caseState.config.height, 1);
    wrap.style.width = Math.round(_caseState.config.width * s) + 'px';
    wrap.style.height = Math.round(_caseState.config.height * s) + 'px';
    const el = wrap.querySelector('.case-canvas');
    if (el) el.style.transform = 'scale(' + s + ')';
}
window.addEventListener('resize', function () { fitCasePreview(); });

// ---------- 表单 ----------
function caseChipHtml(label, active, onclick) {
    return '<button type="button" class="case-chip' + (active ? ' active' : '') + '" onclick="' + onclick + '">' + label + '</button>';
}
function renderCaseForm() {
    const area = document.getElementById('caseFormArea');
    if (!area || !_caseState) return;
    const st = _caseState;
    const cfg = st.config;
    const wm = cfg.watermark;
    const artistName = (defaultSettings && defaultSettings.artistInfo && defaultSettings.artistInfo.id) || '';
    let html = '';
    // 1 关联订单
    html += '<div class="case-form-sec">'
        + '<label class="case-form-label">关联订单</label>'
        + '<select id="caseOrderSelect" class="case-field-input" onchange="applyCaseOrder(this.value)">' + caseOrderOptionsHtml() + '</select>'
        + '<div class="case-form-hint">选择订单后自动带入标题、IP、角色与制品名；此前为该订单上传过的制品图也会一并带出</div>'
        + '</div>';
    // 2 画布比例与尺寸
    html += '<div class="case-form-sec">'
        + '<label class="case-form-label">画布比例</label>'
        + '<div class="case-chips">'
        + caseChipHtml('1:1', cfg.ratio === '1:1', "setCaseRatio('1:1')")
        + caseChipHtml('3:4', cfg.ratio === '3:4', "setCaseRatio('3:4')")
        + caseChipHtml('自定义', cfg.ratio === 'custom', "setCaseRatio('custom')")
        + '</div>'
        + '<div class="case-size-row">'
        + '<input type="number" min="200" max="4000" value="' + cfg.width + '" onchange="setCaseSizeInput(\'w\', this.value)">'
        + '<span class="case-size-x">×</span>'
        + '<input type="number" min="200" max="4000" value="' + cfg.height + '" onchange="setCaseSizeInput(\'h\', this.value)">'
        + '<span class="case-size-x">px</span>'
        + '</div>'
        + '<div class="case-form-hint">比例指案例图整体宽高；制品图始终按原图比例等比缩放，不会被拉伸或裁切。手动改宽高会自动切为自定义比例。</div>'
        + '</div>';
    // 3 背景
    html += '<div class="case-form-sec">'
        + '<label class="case-form-label">背景</label>'
        + '<div class="case-swatch-row">';
    CASE_BG_PRESETS.forEach(function (c) {
        const active = cfg.bg.type === 'color' && String(cfg.bg.color || '').toLowerCase() === c.toLowerCase();
        html += '<button type="button" class="case-swatch' + (active ? ' active' : '') + '" style="background:' + c + ';" onclick="setCaseBg(\'color\',\'' + c + '\')" title="' + c + '"></button>';
    });
    html += '<input type="color" class="case-color-input" value="' + (cfg.bg.type === 'color' ? escapeHtml(cfg.bg.color || '#ffffff') : '#ffffff') + '" onchange="setCaseBg(\'color\', this.value)" title="取色器">'
        + caseChipHtml('透明', cfg.bg.type === 'transparent', "setCaseBg('transparent')")
        + '</div></div>';
    // 4 显示开关
    html += '<div class="case-form-sec">'
        + '<label class="case-form-label">显示内容</label>';
    [['title', '标题'], ['userInfo', '用户信息'], ['productInfo', '制品信息']].forEach(function (p) {
        html += '<div class="case-toggle-row"><span class="case-toggle-name">' + p[1] + '</span>'
            + '<label class="custom-toggle"><input type="checkbox"' + (cfg.toggles[p[0]] ? ' checked' : '') + ' onchange="toggleCaseSection(\'' + p[0] + '\', this.checked)"><span class="toggle-slider"></span></label></div>';
    });
    html += '<div class="case-form-hint">关闭或内容为空时，对应区块不显示、不占位</div>'
        + '</div>';
    // 5 用户信息（四身份多选 + 名字）
    html += '<div class="case-form-sec">'
        + '<label class="case-form-label">用户信息</label>'
        + '<div class="case-chips">'
        + CASE_USER_TYPES.map(function (t) { return caseChipHtml(t, cfg.userInfoTypes.indexOf(t) >= 0, "toggleCaseUserType('" + t + "')"); }).join('')
        + '</div>';
    CASE_USER_TYPES.forEach(function (t) {
        if (cfg.userInfoTypes.indexOf(t) < 0) return;
        html += '<div class="case-userinfo-row"><span class="case-userinfo-type">' + t + '</span>'
            + '<input type="text" value="' + escapeHtml(String((st.fields.userInfo && st.fields.userInfo[t]) || '')) + '" placeholder="显示的名字" oninput="setCaseUserTypeName(\'' + t + '\', this.value)"></div>';
    });
    html += '</div>';
    // 6 样机模板
    html += '<div class="case-form-sec">'
        + '<label class="case-form-label">样机模板</label>'
        + '<div class="case-mockup-grid">'
        + CASE_MOCKUPS.map(function (m) {
            return '<div class="case-mockup-card' + (cfg.mockupId === m.id ? ' active' : '') + '" onclick="setCaseMockup(\'' + m.id + '\')" title="' + escapeHtml(m.desc) + '">'
                + '<div class="case-mockup-diagram">' + m.diagram + '</div>'
                + '<div class="case-mockup-name">' + escapeHtml(m.name) + '</div>'
                + '</div>';
        }).join('')
        + '</div>'
        + '<div class="case-form-hint">上传的制品 PNG 会自动按当前模板的占位区排列并叠加装饰；切换模板即时重新套用</div>'
        + '</div>';
    // 7 制品图
    html += '<div class="case-form-sec">'
        + '<label class="case-form-label">制品图</label>'
        + '<div class="case-upload-zone" id="caseUploadZone">点击或拖拽上传制品 PNG（可多选）<br>自动按样机占位区排列，等比缩放居中</div>'
        + '<input type="file" id="caseImageInput" accept="image/png,image/jpeg,image/webp" multiple class="d-none" onchange="caseHandleImageFiles(this.files); this.value=\'\';">'
        + '<div class="case-thumbs">';
    st.images.forEach(function (imgId, i) {
        const c = _caseImgCache[imgId];
        const src = c ? c.dataUrl : '';
        html += '<div class="case-thumb">'
            + (src ? '<img src="' + src + '" alt="">' : '')
            + '<button type="button" class="case-thumb-del" onclick="caseRemoveImage(\'' + imgId + '\')" title="删除">×</button>'
            + '<div class="case-thumb-ops">'
            + '<button type="button" onclick="caseMoveImage(\'' + imgId + '\',-1)" title="前移">◀</button>'
            + '<button type="button" onclick="caseMoveImage(\'' + imgId + '\',1)" title="后移">▶</button>'
            + '</div></div>';
    });
    html += '</div></div>';
    // 8 字段
    html += '<div class="case-form-sec">'
        + '<label class="case-form-label">案例文字</label>';
    [['title', '标题'], ['ip', 'IP / 原作'], ['character', '角色 / 人物'], ['products', '制品名']].forEach(function (p) {
        html += '<input type="text" class="case-field-input case-field-mb" value="' + escapeHtml(String(st.fields[p[0]] || '')) + '" placeholder="' + p[1] + '" oninput="setCaseField(\'' + p[0] + '\', this.value)">';
    });
    html += '</div>';
    // 9 水印
    html += '<div class="case-form-sec">'
        + '<div class="case-toggle-row"><span class="case-toggle-name">水印</span>'
        + '<label class="custom-toggle"><input type="checkbox"' + (wm.enabled ? ' checked' : '') + ' onchange="setCaseWmEnabled(this.checked)"><span class="toggle-slider"></span></label></div>';
    if (wm.enabled) {
        html += '<div class="case-chips" style="margin-top:6px;">'
            + caseChipHtml('文字', wm.type === 'text', "setCaseWmType('text')")
            + caseChipHtml('图片', wm.type === 'image', "setCaseWmType('image')")
            + '</div>';
        if (wm.type === 'text') {
            html += '<input type="text" class="case-field-input" style="margin-top:9px;" value="' + escapeHtml(String(wm.text || '')) + '" placeholder="水印文字，如 @昵称" oninput="setCaseWmText(this.value)">';
        } else {
            const wmc = _caseImgCache[wm.imgId];
            html += '<div style="margin-top:9px;display:flex;align-items:center;gap:10px;">'
                + (wmc ? '<img src="' + wmc.dataUrl + '" style="width:44px;height:44px;object-fit:contain;border:1px solid var(--border-color,#ddd);border-radius:8px;background:#f4f4f6;padding:3px;">' : '')
                + '<button type="button" class="btn secondary btn-compact" onclick="document.getElementById(\'caseWmImageInput\').click()">上传水印图</button>'
                + '<input type="file" id="caseWmImageInput" accept="image/*" class="d-none" onchange="caseHandleWmImageFile(this.files && this.files[0]); this.value=\'\';">'
                + '</div>';
        }
        html += '<select class="case-field-input" style="margin-top:9px;" onchange="setCaseWmPos(this.value)">'
            + [['br', '右下'], ['bl', '左下'], ['tr', '右上'], ['tl', '左上'], ['center', '居中'], ['tile', '平铺全图']].map(function (p) {
                return '<option value="' + p[0] + '"' + (wm.position === p[0] ? ' selected' : '') + '>' + p[1] + '</option>';
            }).join('')
            + '</select>'
            + '<div class="case-range-row"><span style="font-size:12px;color:var(--text-muted,#999);flex-shrink:0;">透明度</span>'
            + '<input type="range" min="0.05" max="1" step="0.05" value="' + (Number(wm.opacity) || 0.3) + '" oninput="setCaseWmOpacity(this.value)">'
            + '<span class="case-range-val" id="caseWmOpacityVal">' + Math.round((Number(wm.opacity) || 0.3) * 100) + '%</span></div>'
            + '<div class="case-range-row"><span style="font-size:12px;color:var(--text-muted,#999);flex-shrink:0;">大小</span>'
            + '<input type="range" min="0.5" max="3" step="0.1" value="' + (Number(wm.scale) || 1) + '" oninput="setCaseWmScale(this.value)">'
            + '<span class="case-range-val" id="caseWmScaleVal">' + (Number(wm.scale) || 1).toFixed(1) + '×</span></div>';
    }
    html += '<div class="case-form-hint">水印绘制在画布最上层，随导出图一起保存；未开启或无内容时不占位</div>'
        + '</div>';
    area.innerHTML = html;
    // 上传区拖拽
    const zone = document.getElementById('caseUploadZone');
    if (zone) {
        zone.addEventListener('dragover', function (e) { e.preventDefault(); zone.classList.add('dragover'); });
        zone.addEventListener('dragleave', function () { zone.classList.remove('dragover'); });
        zone.addEventListener('drop', function (e) {
            e.preventDefault();
            zone.classList.remove('dragover');
            if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length) caseHandleImageFiles(e.dataTransfer.files);
        });
        zone.addEventListener('click', function () {
            const input = document.getElementById('caseImageInput');
            if (input) input.click();
        });
    }
}
// 表单事件处理（输入类只更新状态 + 预览，不重绘表单，避免输入焦点丢失）
function setCaseRatio(r) {
    const st = _caseState; if (!st) return;
    st.config.ratio = r;
    if (r === '1:1') { st.config.width = 1080; st.config.height = 1080; }
    else if (r === '3:4') { st.config.width = 1080; st.config.height = 1440; }
    renderCaseForm(); renderCasePreview();
}
function setCaseSizeInput(which, v) {
    const st = _caseState; if (!st) return;
    let n = parseInt(v, 10);
    if (!isFinite(n)) return;
    n = Math.min(4000, Math.max(200, n));
    if (which === 'w') st.config.width = n; else st.config.height = n;
    st.config.ratio = 'custom';
    renderCaseForm(); renderCasePreview();
}
function setCaseBg(type, color) {
    const st = _caseState; if (!st) return;
    st.config.bg.type = type;
    if (color) st.config.bg.color = color;
    renderCaseForm(); renderCasePreview();
}
function toggleCaseSection(key, on) {
    const st = _caseState; if (!st) return;
    st.config.toggles[key] = !!on;
    renderCasePreview();
}
function toggleCaseUserType(type) {
    const st = _caseState; if (!st) return;
    const arr = st.config.userInfoTypes;
    const i = arr.indexOf(type);
    if (i >= 0) arr.splice(i, 1);
    else {
        arr.push(type);
        if (!String((st.fields.userInfo && st.fields.userInfo[type]) || '').trim()) {
            st.fields.userInfo[type] = (defaultSettings && defaultSettings.artistInfo && defaultSettings.artistInfo.id) || '';
        }
    }
    renderCaseForm(); renderCasePreview();
}
function setCaseUserTypeName(type, name) {
    const st = _caseState; if (!st) return;
    if (!st.fields.userInfo) st.fields.userInfo = {};
    st.fields.userInfo[type] = name;
    renderCasePreview();
}
function setCaseMockup(id) {
    const st = _caseState; if (!st) return;
    st.config.mockupId = id;
    renderCaseForm(); renderCasePreview();
    if (caseActiveMockup().shadow) {
        caseEnsureShadows((st.images || []).slice()).then(function (changed) {
            if (changed && _caseState) renderCasePreview();
        });
    }
}
function setCaseField(key, value) {
    const st = _caseState; if (!st) return;
    st.fields[key] = value;
    renderCasePreview();
}
function caseMoveImage(imgId, dir) {
    const st = _caseState; if (!st) return;
    const arr = st.images;
    const i = arr.indexOf(imgId);
    const j = i + dir;
    if (i < 0 || j < 0 || j >= arr.length) return;
    arr.splice(j, 0, arr.splice(i, 1)[0]);
    renderCaseForm(); renderCasePreview();
}
function caseRemoveImage(imgId) {
    const st = _caseState; if (!st) return;
    st.images = st.images.filter(function (x) { return x !== imgId; });
    renderCaseForm(); renderCasePreview();
}
async function caseHandleImageFiles(fileList) {
    if (!fileList || !fileList.length || !_caseState) return;
    const files = Array.prototype.slice.call(fileList);
    showGlobalToast('正在处理 ' + files.length + ' 张图片…');
    let okCount = 0;
    for (const file of files) {
        try {
            if (!/^image\//.test(file.type || '')) continue;
            const dataUrl = await caseReadFileAsDataUrl(file);
            const compressed = await caseCompressUploadData(dataUrl, file.type);
            const id = 'cimg_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
            await caseImgPut(id, compressed);
            const img = await caseLoadImageEl(compressed);
            _caseImgCache[id] = { dataUrl: compressed, w: img.naturalWidth || 1, h: img.naturalHeight || 1 };
            _caseState.images.push(id);
            okCount++;
        } catch (e) { console.error('制品图处理失败:', e); }
    }
    if (!_caseState) return;
    renderCaseForm(); renderCasePreview();
    if (caseActiveMockup().shadow) {
        caseEnsureShadows(_caseState.images.slice()).then(function (changed) {
            if (changed && _caseState) renderCasePreview();
        });
    }
    if (okCount) showGlobalToast('已上传 ' + okCount + ' 张制品图，自动套用样机');
    else showGlobalToast('没有可用的图片文件');
}
function setCaseWmEnabled(on) {
    const st = _caseState; if (!st) return;
    const wm = st.config.watermark;
    wm.enabled = !!on;
    if (on && wm.type === 'text' && !String(wm.text || '').trim()) {
        const n = (defaultSettings && defaultSettings.artistInfo && defaultSettings.artistInfo.id) || '';
        wm.text = n ? '@' + n : '';
    }
    renderCaseForm(); renderCasePreview();
}
function setCaseWmType(t) {
    const st = _caseState; if (!st) return;
    st.config.watermark.type = t;
    renderCaseForm(); renderCasePreview();
}
function setCaseWmText(v) {
    const st = _caseState; if (!st) return;
    st.config.watermark.text = v;
    renderCasePreview();
}
function setCaseWmPos(v) {
    const st = _caseState; if (!st) return;
    st.config.watermark.position = v;
    renderCasePreview();
}
function setCaseWmOpacity(v) {
    const st = _caseState; if (!st) return;
    st.config.watermark.opacity = Math.min(1, Math.max(0.05, parseFloat(v) || 0.3));
    const el = document.getElementById('caseWmOpacityVal');
    if (el) el.textContent = Math.round(st.config.watermark.opacity * 100) + '%';
    renderCasePreview();
}
function setCaseWmScale(v) {
    const st = _caseState; if (!st) return;
    st.config.watermark.scale = Math.min(3, Math.max(0.5, parseFloat(v) || 1));
    const el = document.getElementById('caseWmScaleVal');
    if (el) el.textContent = st.config.watermark.scale.toFixed(1) + '×';
    renderCasePreview();
}
async function caseHandleWmImageFile(file) {
    const st = _caseState; if (!st || !file) return;
    try {
        if (!/^image\//.test(file.type || '')) { showGlobalToast('请选择图片文件'); return; }
        const dataUrl = await caseReadFileAsDataUrl(file);
        let compressed = await caseCompressDataUrl(dataUrl, 800, 'image/webp', 0.9);
        if (!compressed || compressed.indexOf('data:image/webp') !== 0) compressed = await caseCompressDataUrl(dataUrl, 800, 'image/png');
        const id = 'cwm_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
        await caseImgPut(id, compressed);
        const img = await caseLoadImageEl(compressed);
        _caseImgCache[id] = { dataUrl: compressed, w: img.naturalWidth || 1, h: img.naturalHeight || 1 };
        st.config.watermark.imgId = id;
        renderCaseForm(); renderCasePreview();
    } catch (e) {
        console.error('水印图处理失败:', e);
        showGlobalToast('水印图处理失败');
    }
}

// ---------- 抽屉 ----------
async function openCaseGenerator(opts) {
    opts = opts || {};
    let base = null;
    if (opts.caseId) {
        base = caseLibrary.find(function (c) { return c && c.id === opts.caseId; }) || null;
    }
    _caseState = base ? caseNormalizeState(JSON.parse(JSON.stringify(base))) : caseNewState();
    const pendingOrderId = (!base && opts.orderId != null && opts.orderId !== '') ? opts.orderId : null;
    const drawer = document.getElementById('caseGeneratorDrawer');
    if (drawer) {
        drawer.classList.add('open');
        drawer.setAttribute('aria-hidden', 'false');
        document.body.style.overflow = 'hidden';
    }
    renderCaseForm();
    renderCasePreview();
    // 异步把案例已有图片读进缓存后补绘
    const ids = (_caseState.images || []).slice();
    const wm = _caseState.config.watermark;
    if (wm && wm.enabled && wm.type === 'image' && wm.imgId) ids.push(wm.imgId);
    await caseEnsureImagesLoaded(ids);
    if (!_caseState) return;
    if (caseActiveMockup().shadow) await caseEnsureShadows(_caseState.images.slice());
    if (pendingOrderId != null) {
        await applyCaseOrder(pendingOrderId);
    } else {
        renderCasePreview();
    }
}
function closeCaseGenerator() {
    const drawer = document.getElementById('caseGeneratorDrawer');
    if (drawer) {
        drawer.classList.remove('open', 'case-preview-shown');
        drawer.setAttribute('aria-hidden', 'true');
    }
    document.body.style.overflow = '';
    toggleCasePreviewDrawer(false);
    _caseState = null;
}
function toggleCasePreviewDrawer(show) {
    const drawer = document.getElementById('caseGeneratorDrawer');
    const pane = document.getElementById('casePreviewPane');
    const backdrop = document.getElementById('casePreviewBackdrop');
    if (!drawer || !pane) return;
    const on = show === undefined ? !pane.classList.contains('case-preview-open') : !!show;
    pane.classList.toggle('case-preview-open', on);
    if (backdrop) {
        backdrop.classList.toggle('case-preview-open', on);
        backdrop.classList.toggle('d-none', false);
    }
    drawer.classList.toggle('case-preview-shown', on);
    if (on) setTimeout(fitCasePreview, 320);
}

// ---------- 导出 / 保存 ----------
async function caseCaptureCanvas(st) {
    const W = st.config.width, H = st.config.height;
    let holder = document.getElementById('caseExportHolder');
    if (!holder) {
        holder = document.createElement('div');
        holder.id = 'caseExportHolder';
        holder.style.cssText = 'position:absolute;left:-10000px;top:0;';
        document.body.appendChild(holder);
    }
    holder.style.width = W + 'px';
    holder.style.height = H + 'px';
    holder.innerHTML = buildCaseCanvasHtml(st);
    const el = holder.firstElementChild;
    casePrepareCanvasEl(el);
    const imgs = el.querySelectorAll('img');
    await Promise.all(Array.prototype.map.call(imgs, function (img) {
        if (img.complete) return Promise.resolve();
        return new Promise(function (res) { img.onload = res; img.onerror = res; });
    }));
    let scale = 1;
    const MAXP = 16.7 * 1024 * 1024;
    if (W * H > MAXP) {
        scale = Math.max(0.4, Math.floor(Math.sqrt(MAXP / (W * H)) * 10) / 10);
        showGlobalToast('画布过大，已按约 ' + Math.round(W * scale) + 'px 导出');
    }
    try {
        return await html2canvas(el, { scale: scale, useCORS: true, logging: false, width: W, height: H, backgroundColor: null });
    } finally {
        holder.innerHTML = '';
    }
}
async function exportCaseAsImage(format) {
    const st = _caseState;
    if (!st) return;
    try {
        const canvas = await caseCaptureCanvas(st);
        let dataUrl;
        if (format === 'jpeg') {
            const cv2 = document.createElement('canvas');
            cv2.width = canvas.width; cv2.height = canvas.height;
            const ctx = cv2.getContext('2d');
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(0, 0, cv2.width, cv2.height);
            ctx.drawImage(canvas, 0, 0);
            dataUrl = cv2.toDataURL('image/jpeg', 0.92);
        } else {
            dataUrl = canvas.toDataURL('image/png');
        }
        const title = String(st.fields.title || '').trim() || '未命名';
        const ext = format === 'jpeg' ? 'jpg' : 'png';
        const filename = '案例_' + title + '_' + Date.now() + '.' + ext;
        const mime = format === 'jpeg' ? 'image/jpeg' : 'image/png';
        const isTouchDevice = ('ontouchstart' in window) || (navigator.maxTouchPoints && navigator.maxTouchPoints > 0);
        const isMobileUA = /Mobi|Android|iPhone|iPod|Windows Phone/i.test(navigator.userAgent);
        const isMobile = isTouchDevice && (window.innerWidth <= 1024 || isMobileUA);
        if (isMobile) {
            canvas.toBlob(async function (blob) {
                if (!blob) { showReceiptImagePreview(dataUrl, filename); return; }
                const file = new File([blob], filename, { type: mime });
                if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
                    try {
                        await navigator.share({ files: [file], title: '案例图' });
                        showGlobalToast('图片已保存');
                    } catch (err) {
                        if (err.name !== 'AbortError') {
                            if (!triggerDownload(dataUrl, filename)) showReceiptImagePreview(dataUrl, filename);
                            else showGlobalToast('图片已保存');
                        }
                    }
                } else {
                    if (!triggerDownload(dataUrl, filename)) showReceiptImagePreview(dataUrl, filename);
                    else showGlobalToast('图片已保存');
                }
            }, mime);
        } else {
            if (!triggerDownload(dataUrl, filename)) showReceiptImagePreview(dataUrl, filename);
            else showGlobalToast('已导出 ' + ext.toUpperCase());
        }
    } catch (e) {
        console.error('导出案例失败:', e);
        alert('导出案例失败，请重试！');
    }
}
async function saveCaseToLibrary() {
    const st = _caseState;
    if (!st) return;
    try {
        showGlobalToast('正在生成案例图…');
        const canvas = await caseCaptureCanvas(st);
        // 成品图压缩 ≤1600：透明背景用 PNG，否则 JPEG；缩略图 ≤480
        const fullMime = st.config.bg.type === 'transparent' ? 'image/png' : 'image/jpeg';
        const full = await caseCompressCanvas(canvas, 1600, fullMime, 0.85);
        const thumb = await caseCompressCanvas(canvas, 480, 'image/jpeg', 0.72);
        const now = new Date().toISOString();
        const oldFull = st.exportImgId, oldThumb = st.exportThumbId;
        const exportImgId = 'cexp_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
        const exportThumbId = 'ctmb_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
        await caseImgPut(exportImgId, full);
        await caseImgPut(exportThumbId, thumb);
        if (oldFull) caseImgDelete(oldFull);
        if (oldThumb) caseImgDelete(oldThumb);
        st.exportImgId = exportImgId;
        st.exportThumbId = exportThumbId;
        st.exportFormat = fullMime === 'image/png' ? 'png' : 'jpeg';
        st.updatedAt = now;
        if (!st.id) {
            st.id = 'case_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
            st.createdAt = now;
        }
        const record = caseRecordFromState(st);
        const idx = caseLibrary.findIndex(function (c) { return c && c.id === st.id; });
        if (idx >= 0) caseLibrary[idx] = record; else caseLibrary.unshift(record);
        saveCaseLibrary();
        showGlobalToast('已保存到案例库' + (st.orderTitle ? '，关联订单「' + st.orderTitle + '」' : ''));
    } catch (e) {
        console.error('保存案例失败:', e);
        alert('保存案例失败，请重试！');
    }
}

// ---------- 案例库 ----------
function renderCaseLibrary() {
    const grid = document.getElementById('caseLibraryGrid');
    if (!grid) return;
    if (!caseLibrary.length) {
        grid.innerHTML = '<div class="case-library-empty">还没有案例。点击右上角「新建案例」，或从记录页订单操作卡选择「生成案例」。</div>';
        return;
    }
    grid.innerHTML = caseLibrary.map(function (c) {
        const title = escapeHtml(String((c.fields && c.fields.title) || '').trim() || '未命名案例');
        const meta1 = c.orderTitle ? '订单：' + escapeHtml(String(c.orderTitle)) : '未关联订单';
        const d = c.updatedAt || c.createdAt || '';
        const meta2 = d ? String(d).slice(0, 10) : '';
        const cid = escapeHtml(String(c.id || ''));
        return '<div class="case-library-card">'
            + '<div class="case-library-thumb" id="caseLibThumb_' + cid + '" onclick="openCaseViewer(\'' + cid + '\')">加载中…</div>'
            + '<div class="case-library-card-body">'
            + '<div class="case-library-card-title">' + title + '</div>'
            + '<div class="case-library-card-meta">' + meta1 + (meta2 ? ' · ' + meta2 : '') + '</div>'
            + '</div>'
            + '<div class="case-library-card-ops">'
            + '<button type="button" class="btn secondary" onclick="regenerateCase(\'' + cid + '\')">重新生成</button>'
            + '<button type="button" class="btn secondary" onclick="downloadCaseById(\'' + cid + '\')">下载</button>'
            + '<button type="button" class="btn secondary" onclick="deleteCaseById(\'' + cid + '\')">删除</button>'
            + '</div>'
            + '</div>';
    }).join('');
    caseFillLibraryThumbs();
}
async function caseFillLibraryThumbs() {
    for (const c of caseLibrary) {
        const el = document.getElementById('caseLibThumb_' + c.id);
        if (!el) continue;
        const id = c.exportThumbId || c.exportImgId;
        if (!id) { el.textContent = '无预览图'; continue; }
        const url = await caseImgGet(id);
        if (url) el.innerHTML = '<img src="' + url + '" alt="">';
        else el.textContent = '图片缺失';
    }
}
async function openCaseViewer(id) {
    const c = caseLibrary.find(function (x) { return x && x.id === id; });
    if (!c) return;
    _caseViewId = id;
    const modal = document.getElementById('caseViewModal');
    const img = document.getElementById('caseViewImg');
    const meta = document.getElementById('caseViewMeta');
    const regen = document.getElementById('caseViewRegenBtn');
    if (!modal || !img) return;
    img.src = '';
    img.alt = '案例加载中…';
    if (meta) meta.textContent = String((c.fields && c.fields.title) || '') + (c.orderTitle ? ' · 订单：' + c.orderTitle : '');
    if (regen) regen.onclick = function () { closeCaseViewModal(); regenerateCase(id); };
    modal.classList.remove('d-none');
    const url = await caseImgGet(c.exportImgId || c.exportThumbId);
    if (url) { img.src = url; img.alt = '案例图'; }
    else img.alt = '图片缺失';
}
function closeCaseViewModal() {
    const modal = document.getElementById('caseViewModal');
    if (modal) modal.classList.add('d-none');
    const img = document.getElementById('caseViewImg');
    if (img) img.src = '';
    _caseViewId = null;
}
function caseViewDownload() {
    if (_caseViewId) downloadCaseById(_caseViewId);
}
async function downloadCaseById(id) {
    const c = caseLibrary.find(function (x) { return x && x.id === id; });
    if (!c || !c.exportImgId) { showGlobalToast('该案例没有可下载的图片，请重新生成'); return; }
    const url = await caseImgGet(c.exportImgId);
    if (!url) { showGlobalToast('案例图片缺失，请重新生成'); return; }
    const title = String((c.fields && c.fields.title) || '未命名').trim();
    const ext = c.exportFormat === 'jpeg' ? 'jpg' : 'png';
    if (!triggerDownload(url, '案例_' + title + '_' + Date.now() + '.' + ext)) {
        showReceiptImagePreview(url, '案例_' + title + '.' + ext);
    }
}
async function deleteCaseById(id) {
    const idx = caseLibrary.findIndex(function (x) { return x && x.id === id; });
    if (idx < 0) return;
    if (!confirm('确定删除该案例？')) return;
    const c = caseLibrary[idx];
    // 仅删除没有被其它案例引用的图片
    const refs = {};
    caseLibrary.forEach(function (o) {
        if (!o || o.id === id) return;
        (o.images || []).forEach(function (i) { refs[i] = 1; });
        const w = o.config && o.config.watermark;
        if (w && w.imgId) refs[w.imgId] = 1;
    });
    const ids = [];
    (c.images || []).forEach(function (i) { if (!refs[i]) ids.push(i); });
    const w = c.config && c.config.watermark;
    if (w && w.imgId && !refs[w.imgId]) ids.push(w.imgId);
    if (c.exportImgId) ids.push(c.exportImgId);
    if (c.exportThumbId) ids.push(c.exportThumbId);
    ids.forEach(function (i) {
        caseImgDelete(i);
        delete _caseImgCache[i];
        delete _caseShadowCache[i];
    });
    caseLibrary.splice(idx, 1);
    saveCaseLibrary();
    renderCaseLibrary();
    showGlobalToast('案例已删除');
}
function regenerateCase(id) {
    openCaseGenerator({ caseId: id });
}
