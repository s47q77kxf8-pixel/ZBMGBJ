# Metton 项目长期备忘

## 基本盘
- **Metton · 接单助手**：画师报价/排单/进度工作台。纯前端（HTML+CSS+JS 无构建），localStorage + Supabase 云同步。仓库 `github.com/s47q77kxf8-pixel/ZBMGBJ`
- 体量：script.js ~3.4万行/1.6MB、index.html ~3.7千行、style.css ~1.35万行 → **大文件务必 Edit 精确替换，禁止整文件重写**
- 自定义许可《Metton 授权许可 1.0》（source-available，禁转售/再分发）；⚠️ 勿改回 MIT/Apache；指纹 `mtn-8e4c1f7a` / `MTN-SIG-2026-4A71-B85D`，台账 `.trae/版权保护/指纹台账.md`，改埋点必更台账
- 目录：`.trae/`=本地工作区（gitignore；`tests/` 全部回归脚本、`documents/`、`版权保护/`）；根目录只留部署文件；`backup_YYYYMMDD_*/` 只留最新 1 个

## 铁律：大文件写操作
- **禁止 python `io.open(...,'w')` 文本模式覆写 script.js/index.html**（LF→CRLF → 4万行全量 diff、写死 `\n` 的测试失配）。改完必核：`open(p,'rb').read().count(b'\r\n')` 应为 0
- 改 style.css/script.js 后**必须同步 index.html 两处 `?v=YYYYMMDD-HHMM`** + script.js `APP_VERSION`（三处同值）

## 校验流程（改完必跑）
测试脚本统一放 `.trae/tests/`，从项目根目录运行；多数支持 `SRC=backup_xxx/script.js` 跑反例（证明用例真能抓旧 bug）。无 package.json；jsdom 测试需 `NODE_PATH=C:/Users/19224/.workbuddy/binaries/node/workspace/node_modules`。
```bash
node --check script.js
node .trae/tests/test_role_profiles.js            # 205/0
node .trae/tests/.presettag_sync_test.js          # 22/0  预设标签同步
node .trae/tests/.cloud_domain_tombstone_test.js  # 13/0  墓碑作用域
node .trae/tests/.rename_sync_test.js             # 14/0  .gift_config_key 10/0
node .trae/tests/.settlement_amount_test.js       # 9/0   .float_order 3/0  .orderremark_merge 4/0
# jsdom 类：.module_move_test 20/0、.case_edit_dock_test 49/0、.case_group_total_test 25/0、
# .case_autobox_render_test 5/5、.case_fx_params_test 63/0、.case_wm_style_test 57/0、
# .case_title_fs_test 15/0、.case_fx_slot_fit_test 15/0
```
- 测试用 eval 注入：函数内 const/let 在 eval 外不可见 → 切片缺顶层辅助函数会 ReferenceError（**新函数要补进 FN_NAMES**）
- ⚠️ jsdom 整段切片类测试末端是写死行号，文件增删行后必须同步调大
- `.price_list_generation_test.js` 是历史坏测试（`mcGeneratedItems is not defined`），不在修改范围内
- ⚠️ 开工先 `git status --short`：项目会被**并行会话**（Trae 或用户自己另开的 WorkBuddy 会话）修改且不提交。收尾发现未提交改动**先问用户，别擅自提交/回滚**；语义有变以当前文件为准改断言

## 云端共用表的最高纪律（2026-09-22 事故）
- `artist_settings_items` 共用表：`process_settings`/`product_settings`/`templates`/各系数域/`schedule_todo_preset_tags` + **`customers`** + **`role_profiles`**，只靠 `domain` 区分 → **任何批量写/删必须先限定 domain**。已修：`mgTrySyncSettingsToCloudV2` 墓碑只打在自己域内
- 拉取单主/角色有自愈护栏：本机有数据、云端合并 0 条时保留本机并回推
- 新增一个 settings 域必须改三处：`mgBuildSettingsV2LocalState`（上传）/`mgApplySettingsV2`（落地+删除过滤）/(可选)变更摘要
- 预设标签行 key = `tag_<标签名>`（勿改随机 id）；变更后走 `saveScheduleTodoPresetTags()`

## 数据/云端约定
- 历史订单 clientId=纯名、contact=平台；单主/角色按名称关联无外键，改名用 `renameHistoryClientId()` 同步
- ⚠️ 改历史订单字段三步：`mg_updated_at=Date.now()` + `markOrderUnsynced` + 上推（`mgSyncOrdersAfterFieldChange`）；只调 `saveData()` 永不上云
- `smartMergeHistory` 按 mg_updated_at 整条二选一（平手留本地）；结算实收走 `getSettlementActualAmount(item)`
- 「基础+递增价」表单 key 必须 `config_<id>_<index>`（制品/赠品同前缀）
- 两端对不上 → 让用户点设置页「以本机为准重传」（`mgForceReuploadAllOrders`）

## 计算页分组渲染坑
- 制品/赠品卡片 class 都是 `.product-item`，id 各自独立计数会撞号 → 查卡片须限定在「本类型本组容器」内
- 卡片内 DOM id 由条目 id 派生 → 同一 id 不能存在两张卡片；「移动条目到别的组」必须**迁移 DOM 节点**；`renderModulePanels()` 后须重挂载该类型所有卡片

## 小票
- `fontSettings.fontSize`(13) 是整票基准；`titleFontSize`(18) 只管标题
- 模板 `receiptTemplates` 数组，不走 Supabase；`generateQuote` 内按阶段自动套用（try/finally 的 `_rcSaved` 还原**勿破坏**）；面板 saveReceiptTemplate/loadSelectedReceiptTemplate/setReceiptTemplateDefault/renderReceiptTemplateList；首页快速切换 `receiptTemplateQuickSelect`

## 价目表两模块
- `priceList.items`（制品设置）+ `priceList.floatItems`（用途/工艺/同模/加急/折扣/其他加价/每制品加费）互相独立；迁移在 `normalizeMarketingCards(mc)`
- 浮动价格**不同系数合并**、每项独立一行；分组顺序（用户指定）：加价类（用途→加急→其他加价→每制品加费）→折扣→工艺→同模
- 预览 `mcPricePreviewRowsHtml`，`data-list` 区分两组，拖拽隔离；「货币/自动同步」开关在「内容」标题行右侧

## 案例库
- **水印**（唯一效果=只绘制在制品不透明像素上；整幅画布/位置/层级开关已删，`wm.over` 恒 'products'）：按槽位烘焙透明 PNG——`caseBakeWmLayer`（水印单元平铺到**中间画布** → `source-in` 单次裁剪；⚠️ 禁止在主画布连续 source-in，单元互不重叠会两两清空）+ `caseWmSig` + `_caseWmBakeCache`(key=`imgId|sig|rot|w x h`；**水印不随制品旋转**)+`_caseWmBakeMiss` 异步补绘
- **入总图/入分图**：组级 `g.noTotal`（整组不进总图）、图级 `config.hiddenImages`（不入分图→连带总图）；可见图集走 `caseGroupVisibleImages(g,st)`；旧 `excludedFromTotal` 已废弃
- **右侧停靠功能区** `#caseEditDock`：上段 `#caseEditGlobal`（制品区微调 caseAreaNudge/Grow、分图比例、文字快选、caseReflowItems、恢复默认）+ 下段 `#caseEditSelBody`（选中设置）；制品摆位存 `cx/cy`；input 聚焦时不重建（焦点保护）
- **左下堆叠文字行高必须按实际字号（含单独 fsScale）算**，否则调大字号会触发缩字/截字（标题变「P…」）；默认布局（fsScale=1）数值零变化
- **数值控件统一 `caseSliderNumRowHtml`**（滑条+数值框+−/＋，↑↓ 按 btnStep 步进）：⚠️ 传参与 setter 量纲须一致（内部小数→控件百分数）；步进走 `caseStepNum`+`window[setter]`（故 setter 一律不带 idx，由 `_caseSelEl`='item:N' 推导）
- **制品装饰（imgFx）**：`config.imgFx[imgId]` = shadow/shadowAlpha/shadowScale/shadowDx/shadowDy、strokeW/Color/Alpha、expandW/Color/Alpha、expandAcrylic、scale、rot；位置 = `config.layout.items[idx]={cx,cy}`（画布百分比，**仅总图页**）
  - 烘焙铁律：透明度一律「临时画布画实色 + `drawAlpha()` 整体一次合成」，**禁止主画布带 globalAlpha 做 caseDilate**（叠深）
  - **外扩 `caseFxBearPx(fx,w,h)`（唯一解算，烘焙与排版共用）+ `caseFxContainBox(cw,ch,bw,bh,bear)`**（contain 前按 `bw/(1+2bear/cw)` 缩一圈，再按整像素等比收敛 → 本体+装饰不越槽位；±90° 时 cw/ch 互换）。副作用：默认模板下本体比无装饰时小一圈（约 10%）

## 仓库约定（用户指定）
- 仓库只放部署必需：script.js / index.html / style.css / login.html / reset-password.html / client.html / supabase-config.js（anon key，需 RLS）/ fonts / .gitignore / LICENSE.md / README.md / 操作指南
- **所有测试脚本不进仓库**：名单写 `.gitignore`「本地回归测试脚本」（新增测试同步加）

## Git 推送（本机实测）
- 裸 `git push` 静默挂起；可靠写法（沙箱外）：
```bash
TOKEN=$(gh auth token); B64=$(printf 'x-access-token:%s' "$TOKEN" | base64 -w0)
GIT_TERMINAL_PROMPT=0 git -c http.sslVerify=false -c "http.extraHeader=Authorization: Basic $B64" push origin main
```
- TLS 吊销检查必失败（`sslVerify=false` 唯一解）；命令里勿出现 `%`；`git update-ref` 不落盘；bash PATH 偶损 → 用 PowerShell
- push 全挂兜底：`gh api` 走 blob→tree→commit→`PATCH /git/refs/heads/main`，之后需一次 `--force-with-lease` 对齐
- push 被拒别急着 merge：先 `git fetch` + `git merge-base --is-ancestor <远程末端> HEAD`，若为真祖先 → `git push --force-with-lease=refs/heads/main:<远程旧SHA> origin main`
- 默认**只本地提交不推送**（用户指定）

## 工作习惯
- 改前备份 `backup_YYYYMMDD_<说明>/`，MD5 校验后动，只留最新 1 个；临时探针/浏览器 profile/预览图用完即删；必要时 `git gc --prune=now`
- 用户自己验证视觉（我不主动截图，只做数值/computed style 验证）；沟通极简、先结论后细节、带核对状态
- 真实浏览器复现：Edge headless + 本地 http.server + 探针页，`--dump-dom` 读精确值；⚠️ `--virtual-time-budget` 冻结过渡 → 先注入 `*{transition:none!important}`
